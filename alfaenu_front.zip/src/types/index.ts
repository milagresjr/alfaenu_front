

export type UtilizadorType = {
    nome: string;
    email: string;
    password: string;
    status: boolean;
}