import { FormService } from "@/features/service/components/FormService";


export default function Page() {
    return (
        <>
            <FormService />
        </>
    )
}