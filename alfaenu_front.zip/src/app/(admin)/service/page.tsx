import ServiceTable from "./_components/ServiceTable";


export default function Page() {
    return(
        <>
            <ServiceTable/>
        </>
    )
}