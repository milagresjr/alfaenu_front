import { FormTermo } from "@/features/term/components/FormTermo";

export default function Page() {
    return (
        <>
            <FormTermo />
        </>
    )
}