import TermTable from "./_components/TermTable";


export default function Page() {
    return(
        <TermTable />
    )
}