import Editor from "@/components/editor/editor";


export default function Page() {
    return(
        <Editor/>
    )
}