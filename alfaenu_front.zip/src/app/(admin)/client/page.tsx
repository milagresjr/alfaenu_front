import ClientTable from "./_components/ClientTable";


export default function Page() {
    return(
        <ClientTable />
    );
}