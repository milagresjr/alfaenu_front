import { FormClient } from "@/features/client/components/FormClient";

export default function Page() {
    return (
        <div>
            <FormClient />
        </div>
    )
}