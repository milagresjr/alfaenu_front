import ContractTable from "./_components/ContractTable";

export default function Page() {
    return(
        <>
            <ContractTable/>
        </>
    )
}