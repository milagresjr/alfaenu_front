import { FormContrato } from "@/features/contract/components/FormContrato";

export default function Page() {
    return(
        <>
            <FormContrato/>
        </>
    )
}