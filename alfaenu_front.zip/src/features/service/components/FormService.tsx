"use client";

import z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import Button from "@/components/ui/button/Button";
import Label from "@/components/form/Label";
import Input from "@/components/form/input/InputField";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useQueryClient } from "@tanstack/react-query";
import { useServiceStore } from "../store/useServiceStore";
import { useCreateServico, useUpdateServico } from "../hooks/useServicesQuery";
import Select from "@/components/form/Select";


const schema = z.object({
    nome: z.string().min(1, { message: "Campo obrigatório" }),
    tipo: z.string(),
    valor: z.string(),
    valor_externo: z.string(),
});

type FormValues = z.infer<typeof schema>;

export function FormService() {

    const { register, handleSubmit, setValue, reset, formState: { errors }, control } = useForm<FormValues>({
        resolver: zodResolver(schema),
        defaultValues: {
            nome: "",
            tipo: "interno",
            valor: "",
            valor_externo: ""
        }
    });

    const { selectedService, setSelectedService } = useServiceStore();

    const route = useRouter();

    const create = useCreateServico();
    const update = useUpdateServico();

    const mode = selectedService ? "edit" : "create";

    const queryClient = useQueryClient();

    const opcoesTipo = [
        { value: 'interno', label: 'Interno' },
        { value: 'externo', label: 'Externo' }
    ];

    const onSubmit = (data: FormValues) => {

        if (selectedService) {
            update.mutate({
                id: selectedService.id,
                nome: data.nome,
                tipo: data.tipo,
                valor: data.valor,
                valor_externo: data.valor_externo,
            }, {
                onSuccess: () => {
                    queryClient.invalidateQueries({
                        queryKey: ["servicos"],
                        exact: false,
                    });
                    toast.success("Serviço atualizado com sucesso");
                    setSelectedService(null);
                    route.push("/service");
                },
                onError: () => {
                    toast.error("Erro ao atualizar Serviço");
                }
            });
        } else {
            create.mutate(data, {
                onSuccess: () => {
                    queryClient.invalidateQueries({
                        queryKey: ["servicos"],
                        exact: false,
                    });
                    toast.success("Serviço criado com sucesso");
                    route.push("/service");
                },
                onError: () => {
                    toast.error("Erro ao criar Serviço");
                }
            });
        }
    }

    useEffect(() => {
        if (selectedService) {
            setValue('nome', selectedService.nome);
            setValue("tipo", selectedService.tipo);
            setValue("valor", String(selectedService.valor));
            setValue("valor_externo", String(selectedService?.valor_externo));
        } else {
            reset();
        }
    }, [selectedService, setValue, reset]);

    return (
        <div className="rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03] p-4">
            <h1 className="text-lg my-3 text-gray-700 dark:text-gray-300">{mode === "create" ? "Criar Serviço" : "Editar Serviço"}</h1>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2 md:grid-cols-6">
                    <div className="col-span-6">
                        <Label>Nome</Label>
                        <Input type="text"
                            placeholder="Nome"
                            name="nome"
                            register={register}
                        />
                        {errors.nome && (
                            <p className="mt-1.5 text-xs text-error-500">
                                {errors.nome.message}
                            </p>
                        )}
                    </div>

                    <div className="col-span-6 md:col-span-3 ">
                        <Label>Tipo</Label>
                        <Controller
                            name="tipo"
                            control={control}
                            render={({ field }) => (
                                <Select
                                    options={opcoesTipo || []}
                                    value={String(field.value)}
                                    onChange={field.onChange}
                                    name={field.name}
                                />
                            )}
                        />
                        {errors.tipo && (
                            <p className="mt-1.5 text-xs text-error-500">
                                {errors.tipo.message}
                            </p>
                        )}
                    </div>

                    <div className="col-span-6 md:col-span-3 ">
                        <Label>Valor</Label>
                        <Input type="number"
                            placeholder="Descrição"
                            name="valor"
                            register={register}
                        />
                        {errors.valor && (
                            <p className="mt-1.5 text-xs text-error-500">
                                {errors.valor.message}
                            </p>
                        )}
                    </div>

                    <div className="col-span-6 md:col-span-3 ">
                        <Label>Valor externo</Label>
                        <Input type="text"
                            placeholder="Descrição"
                            name="valor_externo"
                            register={register}
                        />
                        {errors.valor_externo && (
                            <p className="mt-1.5 text-xs text-error-500">
                                {errors.valor_externo.message}
                            </p>
                        )}
                    </div>

                </div>

                <div className="flex items-center justify-end w-full gap-3 mt-8">
                    <Link href={"/service"}>
                        <Button size="sm" variant="outline">
                            Voltar
                        </Button>
                    </Link>
                    <Button size="sm" variant="primary">
                        Salvar
                    </Button>
                </div>

            </form>
        </div>
    )

}