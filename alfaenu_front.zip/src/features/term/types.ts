

export type TermoType = {
    id?: number;
    titulo: string;
    conteudo: string;
    status?: boolean;
}